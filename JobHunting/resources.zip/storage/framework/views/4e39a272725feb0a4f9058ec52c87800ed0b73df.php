<!DOCTYPE html>

<html lang="en">

<head>
    <!DOCTYPE html>
    <html lang="en">

    <head>

        <!-- META -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="keywords" content="" />
        <meta name="author" content="Yasir Amin" />
        <meta name="robots" content="" />
        <meta name="description" content="" />

        <!-- FAVICONS ICON -->
        <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />

        <!-- PAGE TITLE HERE -->
        <title>Job Hunting Platform | Final Year Project</title>

        <!-- MOBILE SPECIFIC -->
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/feather.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/magnific-popup.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/lc_lightbox.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap-select.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/dataTables.bootstrap5.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/select.bootstrap5.min.css')); ?>">
        <!-- DASHBOARD select bootstrap  STYLE SHEET  -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/dropzone.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/scrollbar.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/datepicker.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/flaticon.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>

<body>


    <!-- LOADING AREA START ===== -->
    <div class="loading-area">
        <div class="loading-box"></div>
        <div class="loading-pic">
            <div class="wrapper">
                <div class="cssload-loader"></div>
            </div>
        </div>
    </div>
    <!-- LOADING AREA  END ====== -->

    <div class="page-wraper">

        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- CONTENT START -->
        <div class="page-content">

            <?php echo $__env->yieldContent('InnerBanner'); ?>


            <!-- OUR BLOG START -->
            <div class="section-full p-t120  p-b90 site-bg-white">


                <div class="container">
                    <div class="row">

                        <div class="col-xl-3 col-lg-4 col-md-12 rightSidebar m-b30">

                            <div class="side-bar-st-1">

                                <div class="twm-candidate-profile-pic">

                                    <img src="<?php echo e(asset('images/user-avtar/pic4.jpg')); ?>" alt="">
                                    <div class="upload-btn-wrapper">

                                        <div id="upload-image-grid"></div>
                                        <button class="site-button button-sm">Upload Photo</button>
                                        <input type="file" name="myfile" id="file-uploader"
                                            accept=".jpg, .jpeg, .png">
                                    </div>

                                </div>
                                <div class="twm-mid-content text-center">
                                    <a href="#" class="twm-job-title">
                                        <h4><?php echo e(Auth::guard('JobSeeker')->user()->name); ?> </h4>
                                    </a>
                                    <p>IT Contractor</p>
                                </div>

                                <div class="twm-nav-list-1">
                                    <ul>
                                        <li class="active"><a href="candidate-dashboard.html"><i
                                                    class="fa fa-tachometer-alt"></i> Dashboard</a></li>
                                        <li><a href="candidate-profile.html"><i class="fa fa-user"></i> My Pfofile</a>
                                        </li>
                                        <li><a href="candidate-jobs-applied.html"><i class="fa fa-suitcase"></i>
                                                Applied Jobs</a></li>
                                        <li><a href="<?php echo e(route('JobSeeker.Logout')); ?>"><i class="fa fa-close"></i>
                                                LogOut</a></li>
                                    </ul>
                                </div>

                            </div>

                        </div>

                        <div class="col-xl-9 col-lg-8 col-md-12 m-b30">
                            <!--Filter Short By-->
                            <div class="twm-right-section-panel site-bg-gray">
                                <div class="wt-admin-right-page-header">
                                    <h2><?php echo e(Auth::guard('JobSeeker')->user()->name); ?></h2>
                                    <p>IT Contractor</p>
                                </div>
                                <?php echo e($slot); ?>



                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- OUR BLOG END -->



        </div>
        <!-- CONTENT END -->

        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>


    <!-- JAVASCRIPT  FILES ========================================= -->
    <script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/waypoints-sticky.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/imagesloaded.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/theia-sticky-sidebar.js')); ?>"></script>
    <script src="<?php echo e(asset('js/lc_lightbox.lite.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dropzone.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.scrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/chart.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>


</body>

</html>
<?php /**PATH C:\Users\yasir\OneDrive\Documents\Github\Job-Hunting\JobHunting\resources\views/layouts/job-seeker.blade.php ENDPATH**/ ?>