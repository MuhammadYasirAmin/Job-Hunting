<?php return array (
  'backend.auth.admin.login-controller' => 'App\\Http\\Livewire\\Backend\\Auth\\Admin\\LoginController',
  'backend.auth.admin.signup-controller' => 'App\\Http\\Livewire\\Backend\\Auth\\Admin\\SignupController',
  'backend.views.admin.admin-dashboard' => 'App\\Http\\Livewire\\Backend\\Views\\Admin\\AdminDashboard',
  'backend.views.company.company-dashboard' => 'App\\Http\\Livewire\\Backend\\Views\\Company\\CompanyDashboard',
  'backend.views.employer.employer-dashboard' => 'App\\Http\\Livewire\\Backend\\Views\\Employer\\EmployerDashboard',
  'backend.views.employer.jobs-post' => 'App\\Http\\Livewire\\Backend\\Views\\Employer\\JobsPost',
  'backend.views.employer.manage-jobs' => 'App\\Http\\Livewire\\Backend\\Views\\Employer\\ManageJobs',
  'backend.views.job-seeker.job-seeker-dashboard' => 'App\\Http\\Livewire\\Backend\\Views\\JobSeeker\\JobSeekerDashboard',
  'frontend.home-page' => 'App\\Http\\Livewire\\Frontend\\HomePage',
  'frontend.jobs.applied-jobs' => 'App\\Http\\Livewire\\Frontend\\Jobs\\AppliedJobs',
);