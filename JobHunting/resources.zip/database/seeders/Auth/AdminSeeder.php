<?php

namespace Database\Seeders\Auth;

use Illuminate\Database\Seeder\Auth;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
